
from flask import Flask, render_template, request, send_file
from weasyprint import HTML
from io import BytesIO

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/generate_pdf', methods=['POST'])
def generate_pdf():
    name = request.form['name']
    domain = request.form['domain']
    duration = request.form['duration']
    issue_date = request.form['issue_date']

    rendered_html = render_template('offer_letter.html',
                                    name=name,
                                    domain=domain,
                                    duration=duration,
                                    issue_date=issue_date)

    pdf_file = BytesIO()
    HTML(string=rendered_html).write_pdf(pdf_file)
    pdf_file.seek(0)

    return send_file(pdf_file, as_attachment=True, download_name='offer_letter.pdf', mimetype='application/pdf')

if __name__ == '__main__':
    app.run(debug=True)
